<?php
$config['charset'] = 'iso-8859-1';
$config['mailtype'] = 'html';
$config['newline'] = '<br/>';
?>