<?php

$config = array('use_page_numbers'	=>	false,
				'first_link'	=>	'&laquo; First',
				'last_link'	=>	'Last &raquo;',
				'next_link'	=>	'Next',
				'prev_link'	=>	'Previous',
				'cur_tag_open'	=>	'<a style="color:#FF8601; font-weight:bold;">',
				'cur_tag_close'	=>	'</a>'
				);
?>