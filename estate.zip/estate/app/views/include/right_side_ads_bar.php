<?php
$ADS = $this->general_model->fetchDataAll("type = 'ad' and status = 'YES'", 'tbl_news', 5, 0, 'ID', 'RANDOM');
if($ADS){
	echo '<div class="col-md-2">';
	foreach($ADS->result() as $res_ads){
		echo '<div class="rightad"><img src="'.base_url().'btPublic/bt-uploads/medium/'.$res_ads->picture.'" style="padding:5px;" width="250" /></div>';
	}
	echo '</div>';
}
?> 