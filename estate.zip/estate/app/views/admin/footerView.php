<div class="ftr-container">

	<div class="footer" style="height:35px;">    	        

        <div class="copyrights" style=" float:right; margin-right:16px;">
        	Copyrights &copy; <?=date('Y').' '.$this->project_model->projectName()?>. All rights reserved.          
        </div>
        <div class="clear"></div>
        <!--<div class="copyrights" style=" float:right; line-height:18px; margin-right:16px;">
            Powered By: 
        </div>-->

    </div>

</div>