<?php
echo '<div class="info_MSG" ><strong>Search Result:</strong> No data found for <font color="#009900"><strong>'.$this->session->userdata($controller__Name.'SEARCH_SESS').'</strong></font><br/>Search again with proper keyword.</div>';
?>